-- ecommerce_db.sql
-- CREATE DATABASE
CREATE DATABASE IF NOT EXISTS ecommerceDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecommerceDB;

-- Drop tables if they exist (safe re-run)
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS product_images;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS addresses;
DROP TABLE IF EXISTS users;

-- Users (system accounts) - example of one-to-one optional to customers
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  role ENUM('admin','staff','customer') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Customers (business entity)
CREATE TABLE customers (
  customer_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  company_name VARCHAR(150),
  first_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(80) NOT NULL,
  phone VARCHAR(30),
  email VARCHAR(150),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_customer_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Addresses (One customer can have many addresses) - 1:N
CREATE TABLE addresses (
  address_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  address_line1 VARCHAR(200) NOT NULL,
  address_line2 VARCHAR(200),
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100),
  postal_code VARCHAR(20),
  country VARCHAR(100) NOT NULL,
  is_billing TINYINT(1) DEFAULT 0,
  is_shipping TINYINT(1) DEFAULT 1,
  CONSTRAINT fk_address_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

-- Categories (product classification) - 1:N to products
CREATE TABLE categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT
);

-- Products
CREATE TABLE products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  sku VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  quantity_in_stock INT NOT NULL DEFAULT 0,
  category_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_product_category FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
);

-- Product images (one product many images) — optional
CREATE TABLE product_images (
  image_id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  image_url VARCHAR(255) NOT NULL,
  alt_text VARCHAR(255),
  CONSTRAINT fk_image_product FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
);

-- Orders
CREATE TABLE orders (
  order_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  shipping_address_id INT,
  billing_address_id INT,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_order_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT,
  CONSTRAINT fk_order_ship_addr FOREIGN KEY (shipping_address_id) REFERENCES addresses(address_id) ON DELETE SET NULL,
  CONSTRAINT fk_order_bill_addr FOREIGN KEY (billing_address_id) REFERENCES addresses(address_id) ON DELETE SET NULL
);

-- Order items (Many-to-Many: orders <-> products through order_items)
CREATE TABLE order_items (
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  price_each DECIMAL(10,2) NOT NULL CHECK (price_each >= 0),
  line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity * price_each) VIRTUAL,
  PRIMARY KEY (order_id, product_id),
  CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
  CONSTRAINT fk_item_product FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
);

-- Useful indexes
CREATE INDEX idx_products_name ON products(name);
CREATE INDEX idx_products_sku ON products(sku);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orderitems_product ON order_items(product_id);

-- Sample data (small)
INSERT INTO categories (name, description) VALUES
('Electronics','Phones, tablets, and accessories'),
('Computers','Laptops and desktops'),
('Accessories','Cables, cases, and peripherals');

INSERT INTO products (sku, name, description, price, quantity_in_stock, category_id) VALUES
('SKU-0001','SuperPhone X','A modern smartphone',699.00,100,1),
('SKU-0002','Ultra Laptop','Lightweight laptop',1299.00,50,2),
('SKU-0003','Wireless Mouse','Ergonomic wireless mouse',29.99,500,3);

INSERT INTO users (username, password_hash, email, role) VALUES
('admin','<hash_placeholder>','admin@example.com','admin');

INSERT INTO customers (user_id, company_name, first_name, last_name, phone, email) VALUES
(1,'ACME Corp','Alice','Admin','+1-555-0000','alice@acme.example');

INSERT INTO addresses (customer_id, address_line1, city, country, is_billing, is_shipping) VALUES
(1,'1 Admin Road','Metropolis','USA',1,1);

-- Example order
INSERT INTO orders (customer_id, shipping_address_id, billing_address_id, total, status) VALUES
(1,1,1, (3 * 699.00) + (1 * 29.99), 'processing');

-- Retrieve recent order id to insert order_items
SET @last_order = LAST_INSERT_ID();

INSERT INTO order_items (order_id, product_id, quantity, price_each) VALUES
(@last_order, 1, 3, 699.00),
(@last_order, 3, 1, 29.99);

-- Update order total (if needed)
UPDATE orders o
JOIN (
  SELECT order_id, SUM(quantity * price_each) AS calc_total
  FROM order_items
  WHERE order_id = @last_order
  GROUP BY order_id
) t ON o.order_id = t.order_id
SET o.total = t.calc_total
WHERE o.order_id = @last_order;

-- End of SQL file
