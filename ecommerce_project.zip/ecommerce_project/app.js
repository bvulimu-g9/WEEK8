require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');

const app = express();
app.use(bodyParser.json());

// DB pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'ecommerceDB',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Basic health
app.get('/', (req, res) => res.json({ ok: true }));

/*
  PRODUCTS CRUD
*/

// Create product
app.post('/products', async (req, res) => {
  try {
    const { sku, name, description, price, quantity_in_stock, category_id } = req.body;
    const [result] = await pool.execute(
      `INSERT INTO products (sku, name, description, price, quantity_in_stock, category_id)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [sku, name, description, price, quantity_in_stock, category_id]
    );
    const [rows] = await pool.execute('SELECT * FROM products WHERE product_id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Read all products (with simple pagination)
app.get('/products', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const offset = parseInt(req.query.offset) || 0;
    const [rows] = await pool.execute('SELECT * FROM products ORDER BY created_at DESC LIMIT ? OFFSET ?', [limit, offset]);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Read single product
app.get('/products/:id', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM products WHERE product_id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Product not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Update product
app.put('/products/:id', async (req, res) => {
  try {
    const fields = ['sku','name','description','price','quantity_in_stock','category_id'];
    const updates = [];
    const values = [];
    for (const f of fields) {
      if (req.body[f] !== undefined) {
        updates.push(`${f} = ?`);
        values.push(req.body[f]);
      }
    }
    if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
    values.push(req.params.id);
    const sql = `UPDATE products SET ${updates.join(', ')} WHERE product_id = ?`;
    await pool.execute(sql, values);
    const [rows] = await pool.execute('SELECT * FROM products WHERE product_id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Delete product
app.delete('/products/:id', async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM products WHERE product_id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Product not found' });
    res.json({ deleted: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

/*
  ORDERS CRUD (Create + Read + Update Status + Delete)
*/

// Create order (expects order with items)
app.post('/orders', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const { customer_id, shipping_address_id, billing_address_id, items } = req.body;
    if (!customer_id || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'customer_id and items are required' });
    }
    await conn.beginTransaction();
    // Insert order placeholder with total=0, will update later
    const [ordResult] = await conn.execute(
      `INSERT INTO orders (customer_id, shipping_address_id, billing_address_id, total, status)
       VALUES (?, ?, ?, 0, 'pending')`,
      [customer_id, shipping_address_id || null, billing_address_id || null]
    );
    const orderId = ordResult.insertId;
    // Insert items
    let total = 0;
    for (const it of items) {
      const { product_id, quantity } = it;
      // get current price
      const [[prod]] = await conn.query('SELECT price FROM products WHERE product_id = ?', [product_id]);
      if (!prod) throw new Error(`Product ${product_id} not found`);
      const price_each = prod.price;
      total += price_each * quantity;
      await conn.execute(
        `INSERT INTO order_items (order_id, product_id, quantity, price_each) VALUES (?, ?, ?, ?)`,
        [orderId, product_id, quantity, price_each]
      );
      // optional: reduce inventory
      await conn.execute('UPDATE products SET quantity_in_stock = quantity_in_stock - ? WHERE product_id = ?', [quantity, product_id]);
    }
    // update order total
    await conn.execute('UPDATE orders SET total = ? WHERE order_id = ?', [total, orderId]);
    await conn.commit();
    const [[order]] = await conn.query('SELECT * FROM orders WHERE order_id = ?', [orderId]);
    res.status(201).json({ order });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    res.status(500).json({ error: err.message });
  } finally {
    conn.release();
  }
});

// Read orders (list)
app.get('/orders', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM orders ORDER BY order_date DESC LIMIT 100');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Read single order (with items)
app.get('/orders/:id', async (req, res) => {
  try {
    const [[order]] = await pool.execute('SELECT * FROM orders WHERE order_id = ?', [req.params.id]);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    const [items] = await pool.execute(
      `SELECT oi.*, p.sku, p.name AS product_name
       FROM order_items oi
       JOIN products p ON oi.product_id = p.product_id
       WHERE oi.order_id = ?`,
      [req.params.id]
    );
    res.json({ order, items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Update order status
app.patch('/orders/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    if (!status) return res.status(400).json({ error: 'status required' });
    await pool.execute('UPDATE orders SET status = ? WHERE order_id = ?', [status, req.params.id]);
    res.json({ updated: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Delete order
app.delete('/orders/:id', async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM orders WHERE order_id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Order not found' });
    res.json({ deleted: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Start server
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on port ${port}`));
